"use client"

import { useEffect, useRef } from "react"

export type ReactorMood = "standby" | "stress" | "alert"
export type ReactorTheme = "blue" | "gold" | "stealth"

type Palette = { glow: [number, number, number]; core: [number, number, number] }

const STANDBY_BY_THEME: Record<ReactorTheme, Palette> = {
  blue: { glow: [34, 211, 238], core: [147, 197, 253] }, // cyan / electric blue
  gold: { glow: [245, 190, 70], core: [255, 224, 150] }, // stark gold
  stealth: { glow: [148, 163, 184], core: [226, 232, 240] }, // steel / white
}

const STRESS: Palette = { glow: [168, 85, 247], core: [245, 191, 100] } // purple / soft amber
const ALERT: Palette = { glow: [239, 68, 68], core: [245, 190, 90] } // crimson / gold

function paletteFor(mood: ReactorMood, theme: ReactorTheme): Palette {
  if (mood === "stress") return STRESS
  if (mood === "alert") return ALERT
  return STANDBY_BY_THEME[theme]
}

function rgba([r, g, b]: [number, number, number], a: number) {
  return `rgba(${r},${g},${b},${a})`
}

type Props = {
  mood: ReactorMood
  /** Active colour theme. */
  theme?: ReactorTheme
  /** Returns a live 0..1 activity level (mic input or TTS output). */
  getLevel: () => number
  /** Receives the backing canvas so a HUD screenshot can be captured. */
  canvasRef?: (el: HTMLCanvasElement | null) => void
  /** Single-tap on the reactor (used for HUD voice barge-in). */
  onTap?: () => void
  className?: string
}

/**
 * Audio-reactive Iron Man Arc-Reactor + visor rendered entirely on <canvas>.
 * Runs its own rAF loop so it never triggers React re-renders per frame.
 */
export function ArcReactor({ mood, theme = "blue", getLevel, canvasRef, onTap, className }: Props) {
  const localRef = useRef<HTMLCanvasElement | null>(null)
  const moodRef = useRef(mood)
  moodRef.current = mood
  const themeRef = useRef(theme)
  themeRef.current = theme

  useEffect(() => {
    const canvas = localRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const SIZE = 340
    const dpr = Math.min(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1, 2)
    canvas.width = SIZE * dpr
    canvas.height = SIZE * dpr
    ctx.scale(dpr, dpr)

    let raf = 0
    let t = 0
    // eased level so the pulse feels physical rather than jittery
    let eased = 0

    const draw = () => {
      t += 0.016
      const target = Math.max(0, Math.min(1, getLevel()))
      eased += (target - eased) * 0.2
      const level = eased

      const { glow, core } = paletteFor(moodRef.current, themeRef.current)
      const cx = SIZE / 2
      const cy = SIZE / 2
      const idle = 0.5 + Math.sin(t * 1.6) * 0.5 // gentle breathing when quiet
      const energy = level * 0.85 + idle * 0.15

      ctx.clearRect(0, 0, SIZE, SIZE)

      // --- outer atmospheric glow ---
      const glowR = 150 + energy * 30
      const g = ctx.createRadialGradient(cx, cy, 20, cx, cy, glowR)
      g.addColorStop(0, rgba(glow, 0.45 + energy * 0.3))
      g.addColorStop(0.5, rgba(glow, 0.12 + energy * 0.12))
      g.addColorStop(1, rgba(glow, 0))
      ctx.fillStyle = g
      ctx.fillRect(0, 0, SIZE, SIZE)

      // --- rotating outer tech ring segments ---
      const segCount = 40
      const ringR = 118
      for (let i = 0; i < segCount; i++) {
        const a = (i / segCount) * Math.PI * 2 + t * 0.4
        const len = 10 + (i % 4 === 0 ? 10 : 0) + energy * 8
        const x1 = cx + Math.cos(a) * ringR
        const y1 = cy + Math.sin(a) * ringR
        const x2 = cx + Math.cos(a) * (ringR + len)
        const y2 = cy + Math.sin(a) * (ringR + len)
        ctx.strokeStyle = rgba(glow, 0.3 + energy * 0.5)
        ctx.lineWidth = i % 4 === 0 ? 2.4 : 1
        ctx.beginPath()
        ctx.moveTo(x1, y1)
        ctx.lineTo(x2, y2)
        ctx.stroke()
      }

      // --- counter-rotating inner arc ring ---
      ctx.strokeStyle = rgba(glow, 0.5 + energy * 0.4)
      ctx.lineWidth = 3
      for (let k = 0; k < 3; k++) {
        const start = -t * 0.9 + (k * Math.PI * 2) / 3
        ctx.beginPath()
        ctx.arc(cx, cy, 92, start, start + Math.PI / 2.4)
        ctx.stroke()
      }

      // --- triangular coil frame (classic arc-reactor look) ---
      const coilR = 66
      const coils = 9
      ctx.lineWidth = 2
      for (let i = 0; i < coils; i++) {
        const a = (i / coils) * Math.PI * 2 + t * 0.2
        const nx = cx + Math.cos(a) * coilR
        const ny = cy + Math.sin(a) * coilR
        ctx.fillStyle = rgba(core, 0.85)
        ctx.shadowColor = rgba(glow, 0.9)
        ctx.shadowBlur = 8 + energy * 14
        ctx.beginPath()
        ctx.arc(nx, ny, 3 + energy * 2, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.shadowBlur = 0

      // outer coil boundary
      ctx.strokeStyle = rgba(glow, 0.55)
      ctx.lineWidth = 2.5
      ctx.beginPath()
      ctx.arc(cx, cy, 78, 0, Math.PI * 2)
      ctx.stroke()

      // --- bright reactor core ---
      const coreR = 34 + energy * 12
      const cg = ctx.createRadialGradient(cx, cy, 2, cx, cy, coreR)
      cg.addColorStop(0, `rgba(255,255,255,${0.9})`)
      cg.addColorStop(0.4, rgba(core, 0.95))
      cg.addColorStop(1, rgba(glow, 0.15))
      ctx.fillStyle = cg
      ctx.shadowColor = rgba(glow, 1)
      ctx.shadowBlur = 30 + energy * 40
      ctx.beginPath()
      ctx.arc(cx, cy, coreR, 0, Math.PI * 2)
      ctx.fill()
      ctx.shadowBlur = 0

      // inner triangle emblem
      ctx.strokeStyle = `rgba(255,255,255,${0.7})`
      ctx.lineWidth = 2
      ctx.beginPath()
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI * 2 - Math.PI / 2 + t * 0.3
        const px = cx + Math.cos(a) * (18 + energy * 5)
        const py = cy + Math.sin(a) * (18 + energy * 5)
        if (i === 0) ctx.moveTo(px, py)
        else ctx.lineTo(px, py)
      }
      ctx.closePath()
      ctx.stroke()

      // --- helmet visor eyes (flare with energy) ---
      const eyeY = cy - 128
      const eyeGap = 26
      const eyeGlow = 0.4 + energy * 0.6
      ;[-1, 1].forEach((dir) => {
        const ex = cx + dir * eyeGap
        ctx.save()
        ctx.translate(ex, eyeY)
        ctx.rotate(dir * -0.18)
        ctx.shadowColor = rgba(glow, 1)
        ctx.shadowBlur = 16 + energy * 22
        const eg = ctx.createLinearGradient(-14, 0, 14, 0)
        eg.addColorStop(0, rgba(core, eyeGlow))
        eg.addColorStop(1, `rgba(255,255,255,${eyeGlow})`)
        ctx.fillStyle = eg
        ctx.beginPath()
        ctx.moveTo(-14, -4)
        ctx.lineTo(14, -1)
        ctx.lineTo(14, 5)
        ctx.lineTo(-14, 4)
        ctx.closePath()
        ctx.fill()
        ctx.restore()
      })
      ctx.shadowBlur = 0

      raf = requestAnimationFrame(draw)
    }

    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [getLevel])

  return (
    <button
      type="button"
      onClick={onTap}
      aria-label="Tap the arc reactor to silence Jarvis"
      className="block cursor-pointer border-0 bg-transparent p-0 outline-none"
    >
      <canvas
        ref={(el) => {
          localRef.current = el
          canvasRef?.(el)
        }}
        style={{ width: 340, height: 340, maxWidth: "88vw", maxHeight: "88vw" }}
        className={className}
        aria-hidden="true"
      />
    </button>
  )
}
