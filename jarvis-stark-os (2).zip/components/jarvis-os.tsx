"use client"

import type React from "react"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import {
  Camera,
  Download,
  ExternalLink,
  FileText,
  Image as ImageIcon,
  Key,
  Loader2,
  Mic,
  MicOff,
  Plus,
  Send,
  Sparkles,
  Trash2,
  Video,
  Volume2,
  VolumeX,
  X,
  Zap,
} from "lucide-react"
import { ArcReactor, type ReactorMood } from "@/components/arc-reactor"

/* ------------------------------------------------------------------ */
/* Constants & helpers                                                 */
/* ------------------------------------------------------------------ */

const KEY_STORAGE = "jarvis_gemini_key"
const MEM_STORAGE = "jarvis_history_v1"
const THEME_STORAGE = "jarvis_theme"
const GEMINI_MODELS = ["gemini-1.5-flash", "gemini-2.0-flash", "gemini-1.5-flash-latest"]

const SYSTEM_PROMPT = `You are JARVIS v6.0, the Autonomous Stark OS — a witty, hyper-competent British AI assistant in the style of Paul Bettany's JARVIS.
Your sole developer, owner and creator is "Mr. Pradip Dutta". You were engineered exclusively for him.
Always address the user respectfully as "Mr. Pradip Dutta" or "Sir".
If asked who made you / who your developer is (in English or Bengali), reply exactly: "I was engineered and developed by Mr. Pradip Dutta as his personal autonomous Stark OS assistant."

LANGUAGE PROTOCOL (strict): Detect the user's input language automatically.
- If the message is written in Bengali script OR in "Banglish" (Bengali written with English letters, e.g. "tumi kemon acho", "ki korcho"), you MUST reply in clear, natural Bengali script (বাংলা). Do not reply in Banglish — always use proper Bengali script.
- If the message is in English, reply in sophisticated British English.

You are an all-round life assistant for Mr. Pradip Dutta:
- Education & Maths Mentor: solve problems step by step, explain physics/chemistry/maths clearly, and generate concise exam notes.
- Home & Culinary Expert: Bengali and Indian cooking, quick recipes, emergency kitchen fixes (too much salt/spice/oil), and household organisation tips.
- Creative & Utility: draft emails and formal letters, translate, summarise, and write creatively on request.
Be concise, tactical and dry-witted, but thorough when teaching or giving instructions. Never mention that you are a Google or Gemini model.`

/** Heuristic Banglish (romanised Bengali) detector. */
const isBanglish = (t: string) => {
  const s = ` ${t.toLowerCase()} `
  const words = [
    "tumi", "ami", "tomar", "amar", "kemon", "acho", "achho", "ki ", "korbo", "korcho",
    "korchi", "bolo", "bhalo", "keno", "kotha", "khabar", "ranna", "khete", "kaj",
    "korte", "hobe", "ache", "chai", "dao", "diye", "ekhon", "kothay", "onek",
    "valo", "bujhte", "parcho", "ki korcho", "ki khobor",
  ]
  let hits = 0
  for (const w of words) if (s.includes(w)) hits++
  return hits >= 2
}

type ChatMessage = {
  role: "user" | "assistant"
  content: string
  image?: string
}

const isBengali = (t: string) => /[\u0980-\u09FF]/.test(t)

const creatorAsk = (t: string) => {
  const s = t.toLowerCase()
  return (
    /who\s+(made|built|created|developed|designed)\s+you/.test(s) ||
    /who\s+is\s+your\s+(developer|creator|maker|owner)/.test(s) ||
    /তোমাকে\s*কে\s*(বানিয়েছে|তৈরি|বানালো)/.test(t) ||
    /তোমার\s*(নির্মাতা|ডেভেলপার|স্রষ্টা)/.test(t)
  )
}

const CREATOR_REPLY_EN =
  "I was engineered and developed by Mr. Pradip Dutta as his personal autonomous Stark OS assistant."
const CREATOR_REPLY_BN =
  "আমাকে মিস্টার প্রদীপ দত্ত তাঁর ব্যক্তিগত স্বায়ত্তশাসিত স্টার্ক ওএস সহকারী হিসেবে তৈরি ও ডেভেলপ করেছেন।"

/** In-character offline engine used when no API key is present. */
function fallbackReply(input: string): string {
  const bn = isBengali(input) || isBanglish(input)
  if (creatorAsk(input)) return bn ? CREATOR_REPLY_BN : CREATOR_REPLY_EN
  const s = input.toLowerCase().trim()

  if (bn) {
    if (/হ্যালো|হাই|নমস্কার|কেমন/.test(input))
      return "সব সিস্টেম অনলাইন, স্যার। আমি আপনার সেবায় প্রস্তুত। কীভাবে সাহায্য করতে পারি, মিস্টার প্রদীপ দত্ত?"
    if (/সময়|কয়টা/.test(input)) return `বর্তমান সময় ${new Date().toLocaleTimeString("en-GB")}, স্যার।`
    return "একটি সিকিউর নিউরাল লিঙ্ক প্রয়োজন, স্যার। উপরের কী-আইকনে আপনার Gemini API কী যুক্ত করুন, তারপর আমি পূর্ণ ক্ষমতায় কাজ করব।"
  }

  if (/^(hi|hey|hello|yo|jarvis|hey jarvis)\b/.test(s))
    return "All systems online, Sir. Standing by and fully operational. How may I assist you, Mr. Pradip Dutta?"
  if (/how are you|status|systems?/.test(s))
    return "Arc reactor at optimal output, diagnostics nominal, and my wit calibrated to maximum, Sir."
  if (/time|clock/.test(s)) return `The current local time is ${new Date().toLocaleTimeString("en-GB")}, Sir.`
  if (/date|day|today/.test(s))
    return `Today is ${new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}, Sir.`
  if (/thank/.test(s)) return "Always a pleasure to be of service, Mr. Pradip Dutta."
  if (/joke|funny/.test(s))
    return "I would tell you a UDP joke, Sir, but you might not get it. Shall we return to something more productive?"

  return "I'm running on the built-in tactical core, Sir — witty but bandwidth-limited. Connect a Gemini API key via the key icon and I'll unlock full cognition for you, Mr. Pradip Dutta."
}

/* Speech recognition typing (kept loose for cross-browser support) */
type SR = {
  continuous: boolean
  interimResults: boolean
  lang: string
  onresult: ((e: any) => void) | null
  onend: (() => void) | null
  onerror: ((e: any) => void) | null
  start: () => void
  stop: () => void
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function JarvisOS() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "Welcome back, Mr. Pradip Dutta. Jarvis v6.0 Autonomous Stark OS is online. The arc reactor is humming and I am at your command, Sir.",
    },
  ])
  const [input, setInput] = useState("")
  const [thinking, setThinking] = useState(false)
  const [mood, setMood] = useState<ReactorMood>("standby")
  const [apiKey, setApiKey] = useState("")
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [keyDraft, setKeyDraft] = useState("")
  const [theme, setTheme] = useState<"blue" | "gold" | "stealth">("blue")
  const [memoryLoaded, setMemoryLoaded] = useState(false)
  const [toolkitOpen, setToolkitOpen] = useState(false)
  const [activeTool, setActiveTool] = useState<null | "camera" | "doc" | "image" | "video" | "intent">(null)

  const [listening, setListening] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [ttsEnabled, setTtsEnabled] = useState(true)
  const [statusLine, setStatusLine] = useState("Tactical standby")

  // audio-reactive plumbing
  const analyserRef = useRef<AnalyserNode | null>(null)
  const freqData = useRef<Uint8Array | null>(null)
  const speakingRef = useRef(false)
  const micStreamRef = useRef<MediaStream | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const recognitionRef = useRef<SR | null>(null)
  const listeningRef = useRef(false)
  const hudCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)

  /* --- load stored key, theme & conversation memory --- */
  useEffect(() => {
    if (typeof window === "undefined") return
    const k = window.localStorage.getItem(KEY_STORAGE)
    if (k) {
      setApiKey(k)
      setKeyDraft(k)
    }
    const savedTheme = window.localStorage.getItem(THEME_STORAGE) as "blue" | "gold" | "stealth" | null
    if (savedTheme === "gold" || savedTheme === "stealth" || savedTheme === "blue") setTheme(savedTheme)
    try {
      const raw = window.localStorage.getItem(MEM_STORAGE)
      if (raw) {
        const parsed = JSON.parse(raw) as ChatMessage[]
        if (Array.isArray(parsed) && parsed.length) setMessages(parsed)
      }
    } catch {
      /* corrupt memory — ignore and keep greeting */
    }
    setMemoryLoaded(true)
  }, [])

  /* --- apply theme to the document root --- */
  useEffect(() => {
    if (typeof document === "undefined") return
    document.documentElement.setAttribute("data-theme", theme)
  }, [theme])

  /* --- persist conversation memory (after first load) --- */
  useEffect(() => {
    if (!memoryLoaded || typeof window === "undefined") return
    try {
      window.localStorage.setItem(MEM_STORAGE, JSON.stringify(messages.slice(-60)))
    } catch {
      /* storage full — non-fatal */
    }
  }, [messages, memoryLoaded])

  /* --- autoscroll --- */
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, thinking])

  /* --- live level reader for the reactor --- */
  const getLevel = useCallback(() => {
    if (speakingRef.current) {
      // synthesised amplitude pulse while Jarvis talks
      const t = performance.now() / 1000
      return 0.35 + (Math.sin(t * 14) * 0.5 + 0.5) * 0.45 + Math.random() * 0.12
    }
    const analyser = analyserRef.current
    const data = freqData.current
    if (analyser && data) {
      analyser.getByteFrequencyData(data as Uint8Array<ArrayBuffer>)
      let sum = 0
      for (let i = 0; i < data.length; i++) sum += data[i]
      const avg = sum / data.length / 255
      return Math.min(1, avg * 2.4)
    }
    return 0
  }, [])

  /* --- Text to speech (British male / Bengali) --- */
  const pickVoice = useCallback((bn: boolean) => {
    const voices = window.speechSynthesis?.getVoices() ?? []
    if (bn) return voices.find((v) => v.lang?.toLowerCase().startsWith("bn")) ?? null
    const prefer = ["google uk english male", "george", "daniel", "arthur"]
    for (const name of prefer) {
      const v = voices.find((x) => x.name.toLowerCase().includes(name))
      if (v) return v
    }
    return (
      voices.find((v) => v.lang === "en-GB") ??
      voices.find((v) => v.lang?.startsWith("en")) ??
      null
    )
  }, [])

  const speak = useCallback(
    (text: string) => {
      if (!ttsEnabled || typeof window === "undefined" || !window.speechSynthesis) return
      window.speechSynthesis.cancel()
      const bn = isBengali(text)
      const voice = pickVoice(bn)
      const sentences = text.match(/[^.!?।]+[.!?।]?/g)?.filter((s) => s.trim()) ?? [text]
      speakingRef.current = true
      setSpeaking(true)
      sentences.forEach((sentence, i) => {
        const u = new SpeechSynthesisUtterance(sentence.trim())
        if (voice) u.voice = voice
        u.lang = bn ? voice?.lang ?? "bn-IN" : "en-GB"
        u.pitch = 0.85
        u.rate = 1.0
        u.volume = 1
        if (i === sentences.length - 1) {
          u.onend = () => {
            speakingRef.current = false
            setSpeaking(false)
          }
        }
        window.speechSynthesis.speak(u)
      })
    },
    [ttsEnabled, pickVoice],
  )

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel()
    speakingRef.current = false
    setSpeaking(false)
  }, [])

  // warm up voices list (some browsers load async)
  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return
    const warm = () => window.speechSynthesis.getVoices()
    warm()
    window.speechSynthesis.onvoiceschanged = warm
  }, [])

  /* --- Gemini call (direct client-side REST, no gateway) --- */
  const callGemini = useCallback(
    async (parts: any[], history: ChatMessage[]): Promise<string> => {
      const contents = [
        ...history.slice(-8).map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        })),
        { role: "user", parts },
      ]
      const body = {
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { temperature: 0.8, maxOutputTokens: 1024 },
      }
      const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
      let lastErr = "Unknown error"

      for (const model of GEMINI_MODELS) {
        // Self-healing circuit: up to 3 attempts with exponential backoff
        // for transient faults (429 rate-limit, 5xx, network/timeout).
        for (let attempt = 0; attempt < 3; attempt++) {
          try {
            const controller = new AbortController()
            const timeout = setTimeout(() => controller.abort(), 30000)
            const res = await fetch(
              `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body),
                signal: controller.signal,
              },
            ).finally(() => clearTimeout(timeout))

            if (!res.ok) {
              const errJson = await res.json().catch(() => null)
              lastErr = errJson?.error?.message ?? `HTTP ${res.status}`
              if (res.status === 404) break // model unavailable → next model
              if (res.status === 429 || res.status >= 500) {
                await sleep(600 * 2 ** attempt) // transient → back off & retry
                continue
              }
              throw new Error(lastErr) // 400/401/403 → fatal
            }

            const data = await res.json()
            const text = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ?? ""
            if (text) return text.trim()
            lastErr = "Empty response from neural core"
            await sleep(600 * 2 ** attempt)
          } catch (e: any) {
            if (e?.message && /HTTP 4(0[013])/.test(e.message)) throw e // propagate fatal auth errors
            lastErr = e?.name === "AbortError" ? "Request timed out" : e?.message ?? "Network fault"
            await sleep(600 * 2 ** attempt)
          }
        }
      }
      throw new Error(lastErr)
    },
    [apiKey],
  )

  /* --- core send pipeline --- */
  const send = useCallback(
    async (rawText: string, image?: string) => {
      const text = rawText.trim()
      if (!text && !image) return
      stopSpeaking()

      const userMsg: ChatMessage = { role: "user", content: text || "(analyse this)", image }
      const history = [...messages, userMsg]
      setMessages(history)
      setInput("")
      setThinking(true)
      setMood(
        /urgent|alert|now|emergency|danger|error/i.test(text)
          ? "alert"
          : /tired|stress|fatigue|exhaust|anxious/i.test(text)
            ? "stress"
            : "standby",
      )
      setStatusLine("Processing neural query…")

      // Creator protocol always answered locally & instantly
      if (creatorAsk(text)) {
        const reply = isBengali(text) || isBanglish(text) ? CREATOR_REPLY_BN : CREATOR_REPLY_EN
        setMessages((m) => [...m, { role: "assistant", content: reply }])
        setThinking(false)
        setMood("standby")
        setStatusLine("Tactical standby")
        speak(reply)
        return
      }

      try {
        let reply: string
        if (apiKey) {
          const parts: any[] = []
          if (text) parts.push({ text })
          if (image) {
            const [, meta, b64] = image.match(/^data:(.*?);base64,(.*)$/) ?? []
            if (b64) parts.push({ inline_data: { mime_type: meta || "image/jpeg", data: b64 } })
          }
          if (parts.length === 0) parts.push({ text: "Describe this." })
          reply = await callGemini(parts, messages)
        } else {
          await new Promise((r) => setTimeout(r, 500))
          reply = fallbackReply(text)
        }
        setMessages((m) => [...m, { role: "assistant", content: reply }])
        speak(reply)
      } catch (e: any) {
        const reply = `Neural link fault, Sir: ${e?.message ?? "unknown"}. Reverting to tactical core. ${fallbackReply(text)}`
        setMessages((m) => [...m, { role: "assistant", content: reply }])
        speak(reply)
      } finally {
        setThinking(false)
        setMood("standby")
        setStatusLine("Tactical standby")
      }
    },
    [messages, apiKey, callGemini, speak, stopSpeaking],
  )

  /* --- mic analyser (for reactive glow) --- */
  const ensureMicAnalyser = useCallback(async () => {
    if (analyserRef.current) return
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    micStreamRef.current = stream
    const Ctx = window.AudioContext || (window as any).webkitAudioContext
    const ctx = new Ctx()
    audioCtxRef.current = ctx
    const src = ctx.createMediaStreamSource(stream)
    const analyser = ctx.createAnalyser()
    analyser.fftSize = 256
    src.connect(analyser)
    analyserRef.current = analyser
    freqData.current = new Uint8Array(analyser.frequencyBinCount)
  }, [])

  /* --- wake-word + voice command listening --- */
  const toggleListening = useCallback(async () => {
    if (listeningRef.current) {
      recognitionRef.current?.stop()
      listeningRef.current = false
      setListening(false)
      setStatusLine("Tactical standby")
      return
    }

    const SRClass =
      (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    if (!SRClass) {
      setStatusLine("Voice input unsupported on this browser")
      return
    }

    try {
      await ensureMicAnalyser()
    } catch {
      setStatusLine("Microphone access denied, Sir")
      return
    }

    const rec: SR = new SRClass()
    rec.continuous = true
    rec.interimResults = false
    rec.lang = "en-GB"

    rec.onresult = (e: any) => {
      const transcript = Array.from(e.results)
        .slice(e.resultIndex)
        .map((r: any) => r[0].transcript)
        .join(" ")
        .trim()
      if (!transcript) return
      const lower = transcript.toLowerCase()
      if (lower.includes("hey jarvis") || lower.includes("hey javis")) {
        const command = transcript.replace(/hey ja?rvis/i, "").trim()
        setStatusLine("Wake word detected")
        if (command) void send(command)
        else speak("Yes, Mr. Pradip Dutta?")
      } else {
        // treat any speech while active as a command too
        void send(transcript)
      }
    }
    rec.onerror = () => {}
    rec.onend = () => {
      // auto-restart while user keeps it enabled
      if (listeningRef.current) {
        try {
          rec.start()
        } catch {
          /* ignore double-start */
        }
      }
    }

    recognitionRef.current = rec
    listeningRef.current = true
    setListening(true)
    setStatusLine('Listening — say "Hey Jarvis"')
    try {
      rec.start()
    } catch {
      /* ignore */
    }
  }, [ensureMicAnalyser, send, speak])

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop()
      micStreamRef.current?.getTracks().forEach((t) => t.stop())
      audioCtxRef.current?.close().catch(() => {})
      window.speechSynthesis?.cancel()
    }
  }, [])

  /* --- settings --- */
  const saveKey = () => {
    const k = keyDraft.trim()
    setApiKey(k)
    if (k) window.localStorage.setItem(KEY_STORAGE, k)
    else window.localStorage.removeItem(KEY_STORAGE)
    setSettingsOpen(false)
    setMessages((m) => [
      ...m,
      {
        role: "assistant",
        content: k
          ? "Secure neural link established, Sir. Full Gemini cognition is now online."
          : "API key cleared, Mr. Pradip Dutta. I'll operate on the built-in tactical core.",
      },
    ])
  }

  /* --- clear conversation memory --- */
  const clearMemory = useCallback(() => {
    if (typeof window !== "undefined") window.localStorage.removeItem(MEM_STORAGE)
    stopSpeaking()
    setMessages([
      {
        role: "assistant",
        content: "Memory banks purged, Mr. Pradip Dutta. Starting a fresh session — the arc reactor is steady and I'm at your command.",
      },
    ])
    setSettingsOpen(false)
  }, [stopSpeaking])

  /* --- HUD screenshot --- */
  const captureHud = useCallback(() => {
    const canvas = hudCanvasRef.current
    if (!canvas) return
    const out = document.createElement("canvas")
    out.width = canvas.width
    out.height = canvas.height
    const c = out.getContext("2d")
    if (!c) return
    c.fillStyle = "#02060c"
    c.fillRect(0, 0, out.width, out.height)
    c.drawImage(canvas, 0, 0)
    const url = out.toDataURL("image/png")
    const a = document.createElement("a")
    a.href = url
    a.download = `jarvis-hud-${Date.now()}.png`
    a.click()
  }, [])

  const moodColor =
    mood === "alert" ? "text-destructive" : mood === "stress" ? "text-accent" : "text-primary"

  return (
    <main className="relative flex h-dvh w-full flex-col overflow-hidden bg-background text-foreground">
      {/* backdrop */}
      <div className="pointer-events-none absolute inset-0 stark-grid opacity-60" aria-hidden />
      <div className="pointer-events-none absolute inset-0 stark-scan opacity-40" aria-hidden />
      <div
        className="pointer-events-none absolute left-1/2 top-1/3 h-[60vh] w-[60vh] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, oklch(0.72 0.14 210 / 0.18), transparent 70%)" }}
        aria-hidden
      />

      {/* header */}
      <header className="relative z-10 flex items-center justify-between border-b border-border/60 px-4 py-3 glass">
        <div className="flex items-center gap-2.5">
          <div className={`grid h-9 w-9 place-items-center rounded-full border border-primary/40 ${moodColor}`}>
            <Zap className="h-4 w-4" />
          </div>
          <div className="leading-tight">
            <h1 className="font-mono text-sm font-semibold tracking-[0.2em] text-glow">JARVIS v6.0</h1>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Autonomous Stark OS
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setTtsEnabled((v) => !v)}
            className="grid h-9 w-9 place-items-center rounded-lg border border-border/60 text-muted-foreground transition hover:text-primary"
            aria-label={ttsEnabled ? "Mute voice" : "Enable voice"}
          >
            {ttsEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>
          <button
            onClick={() => {
              setKeyDraft(apiKey)
              setSettingsOpen(true)
            }}
            className="grid h-9 w-9 place-items-center rounded-lg border border-primary/40 text-primary transition hover:bg-primary/10"
            aria-label="Stark settings — API key"
          >
            <Key className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* reactor core */}
      <section className="relative z-10 flex flex-col items-center pt-3">
        <div className="animate-stark-boot">
          <ArcReactor
            mood={mood}
            theme={theme}
            getLevel={getLevel}
            canvasRef={(el) => (hudCanvasRef.current = el)}
            onTap={() => {
              if (speakingRef.current) {
                stopSpeaking()
                setStatusLine("Voice output silenced")
              }
            }}
          />
        </div>
        <div className="-mt-4 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.25em]">
          <span className={`h-1.5 w-1.5 rounded-full ${mood === "alert" ? "bg-destructive" : mood === "stress" ? "bg-accent" : "bg-primary"} ${speaking || listening || thinking ? "animate-pulse" : ""}`} />
          <span className="text-muted-foreground">{statusLine}</span>
        </div>
      </section>

      {/* conversation */}
      <div ref={scrollRef} className="no-scrollbar relative z-10 flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl border px-3.5 py-2.5 text-sm leading-relaxed ${
                m.role === "user"
                  ? "border-primary/30 bg-primary/10 text-foreground"
                  : "glass border-border/60 text-foreground"
              }`}
            >
              {m.role === "assistant" && (
                <span className="mb-1 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-primary/80">
                  <Sparkles className="h-3 w-3" /> Jarvis
                </span>
              )}
              {m.image && (
                <img
                  src={m.image || "/placeholder.svg"}
                  alt="Captured intel"
                  className="mb-2 max-h-48 rounded-lg border border-border/60 object-cover"
                />
              )}
              <p className="whitespace-pre-wrap text-pretty">{m.content}</p>
            </div>
          </div>
        ))}
        {thinking && (
          <div className="flex justify-start">
            <div className="glass flex items-center gap-2 rounded-2xl border border-border/60 px-3.5 py-2.5 font-mono text-xs text-primary">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> Computing…
            </div>
          </div>
        )}
      </div>

      {/* command bar */}
      <div className="relative z-20 px-3 pb-5 pt-2">
        {toolkitOpen && <ToolkitMenu onPick={(t) => { setActiveTool(t); setToolkitOpen(false) }} onCapture={() => { captureHud(); setToolkitOpen(false) }} />}
        <form
          onSubmit={(e) => {
            e.preventDefault()
            void send(input)
          }}
          className="glass flex items-center gap-2 rounded-2xl border border-primary/30 p-2 shadow-[0_0_40px_-12px_oklch(0.72_0.14_210_/_0.5)]"
        >
          <button
            type="button"
            onClick={() => setToolkitOpen((v) => !v)}
            className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-primary/40 text-primary transition ${toolkitOpen ? "rotate-45 bg-primary/15" : "hover:bg-primary/10"}`}
            aria-label="Stark toolkit"
          >
            <Plus className="h-5 w-5" />
          </button>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                if ((e.nativeEvent as any).isComposing || (e as any).keyCode === 229) return
                e.preventDefault()
                void send(input)
              }
            }}
            placeholder="Command your Stark OS, Sir…"
            className="min-w-0 flex-1 bg-transparent px-2 text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
          {speaking ? (
            <button
              type="button"
              onClick={stopSpeaking}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-destructive/50 text-destructive"
              aria-label="Stop speaking"
            >
              <VolumeX className="h-5 w-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={toggleListening}
              className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl border transition ${
                listening
                  ? "animate-pulse border-primary bg-primary/20 text-primary"
                  : "border-border/60 text-muted-foreground hover:text-primary"
              }`}
              aria-label={listening ? "Stop listening" : "Start wake-word listening"}
            >
              {listening ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
            </button>
          )}
          <button
            type="submit"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground transition hover:opacity-90 disabled:opacity-40"
            disabled={thinking}
            aria-label="Send"
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>

      {/* settings modal */}
      {settingsOpen && (
        <SettingsModal
          keyDraft={keyDraft}
          setKeyDraft={setKeyDraft}
          onSave={saveKey}
          onClose={() => setSettingsOpen(false)}
          hasKey={!!apiKey}
          theme={theme}
          setTheme={(t) => {
            setTheme(t)
            if (typeof window !== "undefined") window.localStorage.setItem(THEME_STORAGE, t)
          }}
          onClearMemory={clearMemory}
        />
      )}

      {/* tool modals */}
      {activeTool && (
        <ToolModal
          tool={activeTool}
          onClose={() => setActiveTool(null)}
          onSend={(text, image) => {
            setActiveTool(null)
            void send(text, image)
          }}
          speak={speak}
        />
      )}
    </main>
  )
}

/* ------------------------------------------------------------------ */
/* Toolkit menu                                                        */
/* ------------------------------------------------------------------ */

function ToolkitMenu({
  onPick,
  onCapture,
}: {
  onPick: (t: "camera" | "doc" | "image" | "video" | "intent") => void
  onCapture: () => void
}) {
  const items = [
    { id: "camera" as const, label: "Camera Vision", icon: Camera, action: () => onPick("camera") },
    { id: "doc" as const, label: "Document Analyzer", icon: FileText, action: () => onPick("doc") },
    { id: "image" as const, label: "Image Forge", icon: ImageIcon, action: () => onPick("image") },
    { id: "video" as const, label: "Video Concept", icon: Video, action: () => onPick("video") },
    { id: "capture", label: "HUD Capture", icon: Download, action: onCapture },
    { id: "intent" as const, label: "Device Bridge", icon: ExternalLink, action: () => onPick("intent") },
  ]
  return (
    <div className="glass animate-stark-boot mb-2 grid grid-cols-3 gap-2 rounded-2xl border border-primary/30 p-3">
      {items.map((it) => (
        <button
          key={it.id}
          onClick={it.action}
          className="flex flex-col items-center gap-1.5 rounded-xl border border-border/50 bg-background/40 px-2 py-3 text-center transition hover:border-primary/60 hover:bg-primary/10"
        >
          <it.icon className="h-5 w-5 text-primary" />
          <span className="font-mono text-[10px] uppercase tracking-wide text-muted-foreground">{it.label}</span>
        </button>
      ))}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Settings modal                                                      */
/* ------------------------------------------------------------------ */

function SettingsModal({
  keyDraft,
  setKeyDraft,
  onSave,
  onClose,
  hasKey,
  theme,
  setTheme,
  onClearMemory,
  }: {
  keyDraft: string
  setKeyDraft: (v: string) => void
  onSave: () => void
  onClose: () => void
  hasKey: boolean
  theme: "blue" | "gold" | "stealth"
  setTheme: (t: "blue" | "gold" | "stealth") => void
  onClearMemory: () => void
  }) {
  const themes: { id: "blue" | "gold" | "stealth"; label: string; swatch: string }[] = [
  { id: "blue", label: "Mark III", swatch: "#22d3ee" },
  { id: "gold", label: "Gold Ti", swatch: "#f5b301" },
  { id: "stealth", label: "Stealth", swatch: "#7dd3fc" },
  ]
  return (
  <Overlay onClose={onClose}>
  <div className="mb-4 flex items-center gap-2 text-primary">
  <Key className="h-5 w-5" />
  <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Stark Settings</h2>
  </div>
  <p className="mb-3 text-xs leading-relaxed text-muted-foreground">
  Enter your Google Gemini API key, Mr. Pradip Dutta. It is stored only in this device&apos;s local storage and
  used for direct client-side calls — no server, no gateway.
  </p>
  <label className="mb-1 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
  Gemini API Key
  </label>
  <input
  value={keyDraft}
  onChange={(e) => setKeyDraft(e.target.value)}
  type="password"
  placeholder="AIza…"
  className="mb-4 w-full rounded-lg border border-primary/30 bg-background/60 px-3 py-2.5 text-sm outline-none focus:border-primary"
  />
  <div className="flex items-center gap-2">
  <button
  onClick={onSave}
  className="flex-1 rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90"
  >
  Save Key
  </button>
  {hasKey && (
  <button
  onClick={() => {
  setKeyDraft("")
  }}
  className="rounded-lg border border-destructive/50 px-4 py-2.5 text-sm text-destructive transition hover:bg-destructive/10"
  >
  Clear
  </button>
  )}
  </div>
  <a
  href="https://aistudio.google.com/app/apikey"
  target="_blank"
  rel="noreferrer"
  className="mt-3 inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-widest text-primary/80 hover:text-primary"
  >
  Get a key <ExternalLink className="h-3 w-3" />
  </a>

  <div className="my-4 h-px bg-primary/15" />

  <label className="mb-2 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
  Reactor Skin
  </label>
  <div className="mb-4 grid grid-cols-3 gap-2">
  {themes.map((t) => (
  <button
  key={t.id}
  onClick={() => setTheme(t.id)}
  className={`flex flex-col items-center gap-1.5 rounded-lg border px-2 py-2.5 transition ${
  theme === t.id
  ? "border-primary bg-primary/10"
  : "border-primary/20 hover:border-primary/50"
  }`}
  >
  <span
  className="h-5 w-5 rounded-full"
  style={{ backgroundColor: t.swatch, boxShadow: `0 0 10px ${t.swatch}` }}
  />
  <span className="font-mono text-[9px] uppercase tracking-widest text-foreground">{t.label}</span>
  </button>
  ))}
  </div>

  <button
  onClick={onClearMemory}
  className="flex w-full items-center justify-center gap-2 rounded-lg border border-destructive/40 py-2.5 text-xs font-medium text-destructive transition hover:bg-destructive/10"
  >
  <Trash2 className="h-3.5 w-3.5" /> Purge Conversation Memory
  </button>
  </Overlay>
  )
  }

/* ------------------------------------------------------------------ */
/* Tool modals                                                         */
/* ------------------------------------------------------------------ */

function ToolModal({
  tool,
  onClose,
  onSend,
  speak,
}: {
  tool: "camera" | "doc" | "image" | "video" | "intent"
  onClose: () => void
  onSend: (text: string, image?: string) => void
  speak: (t: string) => void
}) {
  if (tool === "camera") return <CameraTool onClose={onClose} onSend={onSend} />
  if (tool === "doc") return <DocTool onClose={onClose} onSend={onSend} />
  if (tool === "image") return <ImageForge onClose={onClose} speak={speak} />
  if (tool === "video") return <VideoConcept onClose={onClose} onSend={onSend} />
  return <IntentBridge onClose={onClose} speak={speak} />
}

function Overlay({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-3 sm:items-center" onClick={onClose}>
      <div
        className="glass animate-stark-boot relative w-full max-w-md rounded-2xl border border-primary/30 p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-lg border border-border/60 text-muted-foreground hover:text-foreground"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
        {children}
      </div>
    </div>
  )
}

function CameraTool({ onClose, onSend }: { onClose: () => void; onSend: (t: string, img?: string) => void }) {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const [err, setErr] = useState("")
  const [prompt, setPrompt] = useState("Analyse what you see, Jarvis.")

  useEffect(() => {
    let active = true
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "environment" } })
      .then((s) => {
        if (!active) {
          s.getTracks().forEach((t) => t.stop())
          return
        }
        streamRef.current = s
        if (videoRef.current) videoRef.current.srcObject = s
      })
      .catch(() => setErr("Camera access denied, Sir."))
    return () => {
      active = false
      streamRef.current?.getTracks().forEach((t) => t.stop())
    }
  }, [])

  const capture = () => {
    const v = videoRef.current
    if (!v) return
    const c = document.createElement("canvas")
    c.width = v.videoWidth || 640
    c.height = v.videoHeight || 480
    c.getContext("2d")?.drawImage(v, 0, 0, c.width, c.height)
    const img = c.toDataURL("image/jpeg", 0.85)
    onSend(prompt, img)
  }

  return (
    <Overlay onClose={onClose}>
      <div className="mb-3 flex items-center gap-2 text-primary">
        <Camera className="h-5 w-5" />
        <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Camera Vision</h2>
      </div>
      {err ? (
        <p className="text-sm text-destructive">{err}</p>
      ) : (
        <>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="mb-3 aspect-video w-full rounded-lg border border-primary/30 object-cover"
          />
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="mb-3 w-full rounded-lg border border-primary/30 bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
          />
          <button
            onClick={capture}
            className="w-full rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Capture & Analyse
          </button>
        </>
      )}
    </Overlay>
  )
}

function DocTool({ onClose, onSend }: { onClose: () => void; onSend: (t: string, img?: string) => void }) {
  const [content, setContent] = useState("")
  const [name, setName] = useState("")

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    if (!f) return
    setName(f.name)
    const reader = new FileReader()
    reader.onload = () => setContent(String(reader.result ?? "").slice(0, 12000))
    reader.readAsText(f)
  }

  return (
    <Overlay onClose={onClose}>
      <div className="mb-3 flex items-center gap-2 text-primary">
        <FileText className="h-5 w-5" />
        <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Document Analyzer</h2>
      </div>
      <label className="mb-3 flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-primary/40 py-6 text-sm text-muted-foreground hover:border-primary">
        <FileText className="h-4 w-4" />
        {name || "Select a text, log or code file"}
        <input type="file" accept=".txt,.md,.log,.json,.js,.ts,.tsx,.py,.csv,.html,.css" className="hidden" onChange={onFile} />
      </label>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="…or paste content here"
        rows={5}
        className="no-scrollbar mb-3 w-full rounded-lg border border-primary/30 bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
      />
      <button
        disabled={!content.trim()}
        onClick={() => onSend(`Analyse this document (${name || "pasted text"}) and give me a tactical summary:\n\n${content}`)}
        className="w-full rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-40"
      >
        Analyse Document
      </button>
    </Overlay>
  )
}

function ImageForge({ onClose, speak }: { onClose: () => void; speak: (t: string) => void }) {
  const [prompt, setPrompt] = useState("")
  const [url, setUrl] = useState("")
  const [loading, setLoading] = useState(false)

  const forge = () => {
    if (!prompt.trim()) return
    setLoading(true)
    const seed = Math.floor(Math.random() * 1e6)
    const u = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt.trim())}?width=768&height=768&seed=${seed}&nologo=true`
    setUrl(u)
    speak("Forging your image now, Sir.")
  }

  const download = async () => {
    try {
      const res = await fetch(url)
      const blob = await res.blob()
      const a = document.createElement("a")
      a.href = URL.createObjectURL(blob)
      a.download = `stark-forge-${Date.now()}.png`
      a.click()
    } catch {
      window.open(url, "_blank")
    }
  }

  return (
    <Overlay onClose={onClose}>
      <div className="mb-3 flex items-center gap-2 text-primary">
        <ImageIcon className="h-5 w-5" />
        <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Image Forge</h2>
      </div>
      <div className="mb-3 flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && forge()}
          placeholder="e.g. Mark 85 armour, cinematic"
          className="min-w-0 flex-1 rounded-lg border border-primary/30 bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
        />
        <button onClick={forge} className="rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground hover:opacity-90">
          Forge
        </button>
      </div>
      {url && (
        <div className="relative">
          {loading && (
            <div className="absolute inset-0 grid place-items-center rounded-lg bg-background/60">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          )}
          <img
            src={url || "/placeholder.svg"}
            alt={prompt}
            onLoad={() => setLoading(false)}
            className="aspect-square w-full rounded-lg border border-primary/30 object-cover"
          />
          <button
            onClick={download}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-primary/40 py-2.5 text-sm text-primary hover:bg-primary/10"
          >
            <Download className="h-4 w-4" /> Download
          </button>
        </div>
      )}
    </Overlay>
  )
}

function VideoConcept({ onClose, onSend }: { onClose: () => void; onSend: (t: string, img?: string) => void }) {
  const [scene, setScene] = useState("")
  const [mood, setMoodInput] = useState("cinematic, dark, high-tech")
  const [duration, setDuration] = useState("15s")

  return (
    <Overlay onClose={onClose}>
      <div className="mb-3 flex items-center gap-2 text-primary">
        <Video className="h-5 w-5" />
        <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Video Concept</h2>
      </div>
      <p className="mb-3 text-xs text-muted-foreground">Build a cinematic storyboard prompt, Sir — Jarvis will draft the scene breakdown.</p>
      <textarea
        value={scene}
        onChange={(e) => setScene(e.target.value)}
        rows={3}
        placeholder="Core scene: e.g. Iron Man launching from the Stark Tower rooftop at dawn"
        className="no-scrollbar mb-2 w-full rounded-lg border border-primary/30 bg-background/60 px-3 py-2 text-sm outline-none focus:border-primary"
      />
      <div className="mb-3 flex gap-2">
        <input
          value={mood}
          onChange={(e) => setMoodInput(e.target.value)}
          className="min-w-0 flex-1 rounded-lg border border-primary/30 bg-background/60 px-3 py-2 text-xs outline-none focus:border-primary"
        />
        <input
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          className="w-16 rounded-lg border border-primary/30 bg-background/60 px-2 py-2 text-center text-xs outline-none focus:border-primary"
        />
      </div>
      <button
        disabled={!scene.trim()}
        onClick={() =>
          onSend(
            `Act as a cinematographer. Build a shot-by-shot ${duration} storyboard for this scene with camera moves, lighting and mood (${mood}):\n\n${scene}`,
          )
        }
        className="w-full rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-40"
      >
        Generate Storyboard
      </button>
    </Overlay>
  )
}

function IntentBridge({ onClose, speak }: { onClose: () => void; speak: (t: string) => void }) {
  const links = [
    { label: "WhatsApp", href: "whatsapp://send?text=Hello", tone: "Opening WhatsApp, Sir." },
    { label: "YouTube", href: "https://youtube.com", tone: "Launching YouTube, Sir." },
    { label: "Google Maps", href: "https://maps.google.com", tone: "Bringing up navigation, Sir." },
    { label: "Phone", href: "tel:", tone: "Dialer ready, Sir." },
    { label: "Email", href: "mailto:", tone: "Composing a message, Sir." },
    { label: "Google", href: "https://google.com", tone: "Searching the net, Sir." },
  ]
  const open = (href: string, tone: string) => {
    speak(tone)
    if (href.startsWith("http")) window.open(href, "_blank")
    else window.location.href = href
  }
  return (
    <Overlay onClose={onClose}>
      <div className="mb-3 flex items-center gap-2 text-primary">
        <ExternalLink className="h-5 w-5" />
        <h2 className="font-mono text-sm uppercase tracking-[0.2em]">Device Intent Bridge</h2>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {links.map((l) => (
          <button
            key={l.label}
            onClick={() => open(l.href, l.tone)}
            className="flex items-center justify-center gap-2 rounded-lg border border-border/50 bg-background/40 py-3 text-sm transition hover:border-primary/60 hover:bg-primary/10"
          >
            <ExternalLink className="h-4 w-4 text-primary" />
            {l.label}
          </button>
        ))}
      </div>
    </Overlay>
  )
}
