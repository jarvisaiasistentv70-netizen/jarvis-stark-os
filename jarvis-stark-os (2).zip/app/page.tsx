import { JarvisOS } from "@/components/jarvis-os"

export default function Page() {
  return <JarvisOS />
}
